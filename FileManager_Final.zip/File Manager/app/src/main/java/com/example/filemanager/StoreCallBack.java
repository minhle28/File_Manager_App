package com.example.filemanager;

public interface StoreCallBack {
    void startChooseDestination();
}
